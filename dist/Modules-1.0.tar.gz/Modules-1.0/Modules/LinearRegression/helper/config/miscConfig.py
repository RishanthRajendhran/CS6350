gradientDescent = "batch"
loss = "lms"
conditions = {}
shuffleData = False
learningRate = [1]
validationSplit = 0.3