# CS6350
This is a machine learning library developed by Rishanth Rajendhran for CS6350 in University of Utah.
