import numpy as np
import argparse
import matplotlib.pyplot as plt