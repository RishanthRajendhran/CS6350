import numpy as np
import sys
import argparse
import os
from sklearn import preprocessing
from sklearn import datasets