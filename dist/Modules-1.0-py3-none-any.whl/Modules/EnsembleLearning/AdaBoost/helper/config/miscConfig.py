allowedWeakLearners = ["decisionTree"]
weakLearner = "decisionTree"
numWeakLearners = 100
validationSplit = 0.3
shuffleData = False
conditions = {
    "maxDepth": 1,
    "metric": "e",
}
allLabels = None